from django.shortcuts import render,redirect
from django.contrib.auth.models import User
from django.contrib.auth import login,logout,authenticate
from django.contrib import messages
from .models import Add
from .forms import AddForm

# Create your views here.
def indexview(request):
    return render(request,'index.html')

def registerview(request):
    if request.method=="POST":
        username=request.POST['username']
        email=request.POST['email']
        password=request.POST['password']
   

        usr=User(username=username,email=email)
        usr.set_password(password)
        usr.save()

        return redirect('login')
        
    return render(request,'register.html')


def loginview(request):
    if request.method=="POST":
        username=request.POST['username']
        password=request.POST['password']

        usr=authenticate(username=username,password=password)

        if usr is None:
            messages.info(request,"You have entered an invalid username or password")
            return redirect('login')

        login(request,usr)
        return redirect('add')


    return render(request,'login.html')

def logoutview(request):
    if request.user.is_authenticated:
        logout(request)
        return redirect('index')

def aboutview(request):
    return render(request,'aboutus.html')

def addview(request):
    if request.method=="POST":
        name=request.POST['name']
        age=request.POST['age']
        gender=request.POST['gender']
        bloodgroup=request.POST['bloodgroup']

        add=Add(name=name,age=age,gender=gender,bloodgroup=bloodgroup)
        add.save()

    all_add=Add.objects.all()
    return render(request,'add.html',{'all_add':all_add})

def editview(request,id):
    if request.method =="POST":
        edit = Add.objects.get(pk=id)
        form=AddForm(request.POST,instance=edit)

        if form.is_valid():
            form.save()
    else:
        edit=Add.objects.get(pk=id)
        form=AddForm( instance=edit)

    return render(request,'edit.html',{'form':form})

def delview(request,id):
    dlt=Add.objects.get(pk=id)
    dlt.delete()
    return redirect('add')
