from django.apps import AppConfig


class BloodappConfig(AppConfig):
    name = 'BloodApp'
